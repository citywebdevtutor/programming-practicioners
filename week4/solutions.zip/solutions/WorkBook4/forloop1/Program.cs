﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forloop1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            int counter;
            double hours, rate, salary;
            for (counter = 1; counter < 6; counter++)
            {
                // 1. Prompt user for hours worked
                Console.Write("Enter hours worked: ");
                hours = double.Parse(Console.ReadLine());

                // 2. Prompt user for rate of pay
                Console.Write("Enter rate of pay: ");
                rate = double.Parse(Console.ReadLine());

                // 3. Calculate salary (hours * rate)
                salary = hours * rate;

                // 4. Display salary to 2 decimal points
                Console.WriteLine($"Salary for Employee {counter}: £{salary:F2}\n");

            }
           
            Console.ReadKey();
        }
    }
}
