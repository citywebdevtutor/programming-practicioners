﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace whileLoop2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int value, total = 0;
            Console.Write("Enter a value to be summed or 999 to stop ");
            value = Convert.ToInt32(Console.ReadLine());
            while (value != 999)
            {
                total = total + value;
                Console.Write("Enter a value to be summed or 999 to stop ");
                value = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("\nThe total is " + total);
            Console.ReadKey();
        }
    }
}
