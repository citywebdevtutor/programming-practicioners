﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forLoop2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            double sum = 0;
            double number;

            Console.WriteLine("Enter three different numbers:");
            /* loop through program 3 times and ask user for number 
             * each time & add to sum varaible for each iteration */ 
            for (int i = 1; i <= 3; i++)
            {
                Console.WriteLine("Please enter number: " + i);
                number = Convert.ToDouble(Console.ReadLine()); // convert to double
                sum += number; // add to sum
                    
            }

            Console.WriteLine("The sum of the three numbers is: " + sum); // confirm total after loop breaks

            Console.ReadKey();
        }
    }
}
