﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doWhile3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double payrate = 8.75;
            double hoursWorked;
            double grossWage;
            string cont = "Y";

            while (true) // Continuously prompt for hours worked
            {
                if (cont == "Y") // contineu yes or no
                {
                    Console.Write("Enter hours worked: ");
                    hoursWorked = Convert.ToDouble(Console.ReadLine());
                                    
                    if (hoursWorked > 0)
                    {
                        // Calculate gross wage
                        grossWage = hoursWorked * payrate;

                        // Display pay rate
                        Console.WriteLine("Pay rate: " + Math.Round(payrate, 2));

                        // Display gross wage
                        Console.WriteLine($"Gross wage for {hoursWorked} hours worked: £{grossWage:F2}");
                        Console.WriteLine("Do you want to continue? (Y or N)");
                        cont = Console.ReadLine().ToUpper(); //cast input to uppercase
                    }
                    else
                    {
                        // User entered 0 or a negative value, exit the loop
                        break;
                    }
                }
                else { break; }
                    
            }

            Console.WriteLine("Thank you for using the wage calculator. Press any key to quit...");
            Console.ReadKey();
        }
    }
}
