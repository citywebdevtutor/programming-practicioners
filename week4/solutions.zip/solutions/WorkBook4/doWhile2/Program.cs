﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doWhile2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double payrate = 8.75;
            double hoursWorked;
            double grossWage;

            while (true) // Continuously prompt for hours worked
            {
                Console.Write("Enter hours worked (or 0 to quit): ");
                hoursWorked = Convert.ToDouble(Console.ReadLine());

                if (hoursWorked > 0)
                {
                    // Calculate gross wage
                    grossWage = hoursWorked * payrate;

                    // Display pay rate
                    Console.WriteLine("Pay rate: " + Math.Round(payrate, 2));

                    // Display gross wage
                    Console.WriteLine($"Gross wage for {hoursWorked} hours worked: £{grossWage:F2}");
                }
                else
                {
                    // User entered 0 or a negative value, exit the loop
                    break;
                }
            }

            Console.WriteLine("Thank you for using the wage calculator. Press any key to quit...");
            Console.ReadKey();
        }
    }
}
