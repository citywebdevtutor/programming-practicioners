﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doWhile1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //set the Windows Title
            Console.Title = "do while Loop 1 Program";
            int count = 0;
            do
            {
                count++;
                Console.Write("Count is " + count);
                Console.WriteLine();
            } while (count < 20);

            Console.ReadKey();
        }
    }
}
