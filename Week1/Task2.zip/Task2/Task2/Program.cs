﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            int num1, num2, sum;

            // prompt user for first number
            Console.Write("Please enter your first number... ");
            num1 = Convert.ToInt32(Console.ReadLine());

            // prompt user for second number
            Console.Write("Please enter your second number... ");
            num2 = Convert.ToInt32(Console.ReadLine());

            // addition of the 2 variable values and assign to variable sum
            sum = num1 + num2;
            // write out sum value to console
            Console.Write(sum);

            Console.ReadKey();
        }
    }
}
