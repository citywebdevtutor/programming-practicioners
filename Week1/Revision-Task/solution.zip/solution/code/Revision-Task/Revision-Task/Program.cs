﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Revision_Task
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // start code here

            // Declare variables
            Double itemCost;
            Int32 numItems;
            Double totalCost;

            Console.Write("Please enter the cost of the item... £"); // Instructions to user
            // User input is a string, convert input to integer using ToDouble method
            itemCost = Convert.ToDouble(Console.ReadLine()); // Assign input to variable

            Console.Write("Please enter the number of items you wish to purchase... "); // Instructions to user
            // User input is a string, convert number to integer using ToInt32 method
            numItems = Convert.ToInt32(Console.ReadLine()); // Assign input to variable

            totalCost = itemCost * numItems; // multiply itemCost by numItems and assign to totalCost variable
            Console.WriteLine("The total cost of your purchase is... £" + totalCost); // Display totoal cost of purchase to user
            Console.ReadKey(); // ReadKey() method stops program until user presses key

            // end code here
        }
    }
}
