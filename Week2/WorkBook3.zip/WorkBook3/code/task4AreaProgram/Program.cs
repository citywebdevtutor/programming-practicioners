﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task4AreaProgram
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
                // pi is constant that represents the ratio of the circumference of a circle to its diameter
                const double pi = 3.142;
                //The variable type called ‘double’ allows for a decimal point
                double radius;
                double area;
                double circumference;

                //prompt user for radius
                Console.Write("Please enter the radius of the circle > ");
                // The radius of a circle is the length of a straight line segment that connects the center of the circle to a point on the circle's edge
                radius = Convert.ToDouble(Console.ReadLine()); // diameter is distance from inside edge to edge of circle
                area = pi * (radius * radius);  // The area of a circle is how much space is inside the circle
                circumference = 2 * pi * radius; // The circumference of a circle is the  total length of the circle's outer curve

                Console.WriteLine("The area of your circle is: " + area);
                 Console.WriteLine("The circumference of your circle is: " + circumference);

            Console.ReadKey();
       

        }
    }
}
