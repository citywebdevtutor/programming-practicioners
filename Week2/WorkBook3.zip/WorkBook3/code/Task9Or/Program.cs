﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task9Or
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            int weight, area;
            Console.WriteLine("Please enter the weight of your item... ");  //Prompt user
            weight = Convert.ToInt32(Console.ReadLine()); // Convert input to int and assign to variable weight
            Console.WriteLine("Please enter the area of your item... ");  //Prompt user
            area = Convert.ToInt32(Console.ReadLine()); // Convert input to int and assign to variable area

            if (weight > 30 || area > 150) // if weight OR area are greater than their conditions
            {
                Console.WriteLine("The delivery cost is £50."); // delivery is £50
            }
            else
            {
                Console.WriteLine("The delivery cost is £10."); // else delivery is £10
            }

            Console.ReadKey();
        }
    }
}
