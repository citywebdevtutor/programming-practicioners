﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task8ElseIf
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int mark;
            Console.Write("Please enter your mark... "); // Prompt user to enter mark
            mark = Convert.ToInt32(Console.ReadLine());  // convert input to int32 and assign to mark variable
            if (mark >= 90)
            {
                Console.WriteLine(mark + " Your grade is A");
            }
            else if (mark >= 80)
            {
                Console.WriteLine(mark + " Your grade is B");
            }
            else if (mark >= 70)
            {
                Console.WriteLine(mark + " Your grade is C");
            }
            else if (mark >= 60)
            {
                Console.WriteLine(mark + " Your grade is D");
            }
            else
            {
                Console.WriteLine(mark + " Your grade is E");
            }
     
            Console.ReadKey();
        }
    }
}
