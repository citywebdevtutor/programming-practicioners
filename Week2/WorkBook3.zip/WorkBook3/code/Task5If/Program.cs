﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task5If
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int temp; // declare temp variable of int data type
            Console.Write("Please enter the temperature... ");// Prompt user for temp
            temp = Convert.ToInt32(Console.ReadLine());  // Convert user input to int and assign value to temp variable
           
            if (temp <= 32)
            {
              Console.WriteLine("It is Freezing..");
            }

            Console.ReadKey(); // ReadKey() method makes screen pause until user hits a key
        }
    }
}
