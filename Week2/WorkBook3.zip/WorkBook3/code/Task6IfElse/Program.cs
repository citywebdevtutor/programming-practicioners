﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task6IfElse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int passmark = 50; // assign value 50 to const passmark of int data type
            int mark; // decalre mark variable as int data type
            Console.WriteLine("Enter a mark in range 0 to 100 "); // prompt user to input mark
            mark = Convert.ToInt32(Console.ReadLine()); // convert input to integer and assign to variable

            if (mark >= passmark) // if value of mark is greater than or equal to 50 (value of passmark)
            {
                Console.WriteLine("Pass, your mark was " + mark); // message to user as a pass and confirm their mark
            }
            else // else
            {
                Console.WriteLine("Fail, your mark was " + mark); // message to user as a fails and confirm their mark
            }
            Console.ReadKey(); // stops program until user presses key
        }
    }
}
